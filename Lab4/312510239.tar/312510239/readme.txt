1. make
2. ./Lab4 [inputfilename] [outputfilename]