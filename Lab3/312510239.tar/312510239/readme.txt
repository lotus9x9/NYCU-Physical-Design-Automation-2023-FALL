1. make
2. ./Lab3 [inputfilename] [outputfilename]