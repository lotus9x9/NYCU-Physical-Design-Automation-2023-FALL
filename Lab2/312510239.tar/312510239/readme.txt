1. make
2. ./Lab2 [inputfilename] [outputfilename]